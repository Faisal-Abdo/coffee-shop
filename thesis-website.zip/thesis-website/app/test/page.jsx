import React from 'react'

// Example of a minimal component
function TestImage() {
    return <img src="./images/burger-1.jpg" alt="Test" />;
  }
  

export default TestImage;