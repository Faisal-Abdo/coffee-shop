import React from 'react'

const NewPage = () => {
  return (
    <div>NewPage</div>
  )
}

export default NewPage