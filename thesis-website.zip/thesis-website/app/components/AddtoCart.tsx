'use client';
import React from 'react'

const AddtoCart = () => {
  return (
    <div> <button onClick={ () => console.log('Click')}>Add to Cart </button> </div>
  
  )
}

export default AddtoCart