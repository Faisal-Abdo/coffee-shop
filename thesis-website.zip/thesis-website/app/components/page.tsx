import React from 'react'
import AddtoCart from './AddtoCart'

const ProductCard = () => {
  return (
    <AddtoCart/>
  )
}

export default ProductCard