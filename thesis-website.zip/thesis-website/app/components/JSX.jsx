import React from 'react';

function MyComponent({ children }) {
  return (
    <div>{children}</div>
  );
}

export default MyComponent;
